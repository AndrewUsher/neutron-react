'use strict';
module.exports = require('../../full/iterator/dispose');
