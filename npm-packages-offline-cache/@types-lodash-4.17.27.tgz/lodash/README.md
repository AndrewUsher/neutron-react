# Installation
> `npm install --save @types/lodash`

# Summary
This package contains type definitions for lodash (https://lodash.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash.

### Additional Details
 * Last updated: Wed, 21 Oct 2026 15:38:39 GMT
 * Dependencies: none

# Credits
These definitions were written by [Brian Zengel](https://github.com/bczengel), [Ilya Mochalov](https://github.com/chrootsu), [AJ Richardson](https://github.com/aj-r), [e-cloud](https://github.com/e-cloud), [Jack Moore](https://github.com/jtmthf), [Dominique Rau](https://github.com/DomiR), and [William Chelman](https://github.com/WilliamChelman).
