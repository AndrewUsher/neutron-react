/*
 * This file was automatically generated.
 * DO NOT MODIFY BY HAND.
 * Run `yarn fix:special` to update
 */
declare const check: (options: import("../../../declarations/plugins/schemes/VirtualUrlPlugin").VirtualUrlPluginOptions) => boolean;
export = check;
