<div align="center">
  <a href="https://github.com/webpack/webpack">
    <img width="200" height="200" src="https://webpack.js.org/assets/icon-square-big.svg">
  </a>
</div>

[![npm][npm]][npm-url]
[![node][node]][node-url]
[![tests][tests]][tests-url]
[![cover][cover]][cover-url]
[![discussion][discussion]][discussion-url]
[![size][size]][size-url]

# minimizer-webpack-plugin

This plugin minifies your assets in a webpack build. It ships with several
built-in minimizers covering JavaScript, JSON, HTML, CSS, and images — pick one
with the [`minify`](#minify) option and target the right files with
[`test`](#test).

JavaScript minimizers:

- [`terser`](https://github.com/terser/terser) — `MinimizerPlugin.terserMinify` (default). The same JavaScript-based minifier that webpack uses out of the box; produces small, well-tested output and supports the full set of `extractComments` modes.
- [`uglify-js`](https://github.com/mishoo/UglifyJS) — `MinimizerPlugin.uglifyJsMinify`. ES5-only minifier, useful when you specifically need UglifyJS-compatible output. Requires `npm install --save-dev uglify-js`.
- [`@swc/core`](https://github.com/swc-project/swc) — `MinimizerPlugin.swcMinify`. A very fast Rust-based JavaScript/TypeScript minifier. Requires `npm install --save-dev @swc/core`.
- [`esbuild`](https://github.com/evanw/esbuild) — `MinimizerPlugin.esbuildMinify`. An extremely fast JS bundler/minifier; legal comments are always preserved (no `extractComments` support). Requires `npm install --save-dev esbuild`.

JSON minimizer:

- `JSON.stringify` — `MinimizerPlugin.jsonMinify`. Built in (no extra dependency); supports `space` and `replacer` options.

HTML minimizers:

- webpack's own — `webpack.html.syntax.htmlMinify`. Ships with webpack (`>= 5.111.0`), so it needs no extra dependency, and it is the one that minifies what a document nests: an inline `<style>`, every `style=""`, a `<script>`, an `<svg>` subtree. See [webpack's own minimizers](#webpacks-own-minimizers).
- [`html-minifier-terser`](https://github.com/terser/html-minifier-terser) — `MinimizerPlugin.htmlMinifierTerser`. JavaScript-based, no native dependency. Requires `npm install --save-dev html-minifier-terser`.
- [`@swc/html`](https://github.com/swc-project/swc) — `MinimizerPlugin.swcMinifyHtml` (full HTML documents) and `MinimizerPlugin.swcMinifyHtmlFragment` (HTML fragments, e.g. `<template>` content). Very fast Rust-based platform for the Web. Requires `npm install --save-dev @swc/html`.
- [`@minify-html/node`](https://github.com/wilsonzlin/minify-html) — `MinimizerPlugin.minifyHtmlNode`. A Rust HTML minifier optimised for speed and effectiveness. Requires `npm install --save-dev @minify-html/node`.

CSS minimizers:

- webpack's own — `webpack.css.syntax.cssMinify`. Ships with webpack (`>= 5.111.0`), so it needs no extra dependency, and it minifies the CSS a stylesheet or a document nests. See [webpack's own minimizers](#webpacks-own-minimizers).
- [`cssnano`](https://cssnano.github.io/cssnano/) — `MinimizerPlugin.cssnanoMinify`. Built on top of [PostCSS](https://postcss.org/). Requires `npm install --save-dev cssnano postcss`.
- [`csso`](https://github.com/css/csso) — `MinimizerPlugin.cssoMinify`. A CSS minifier with structural optimisations. Requires `npm install --save-dev csso`.
- [`clean-css`](https://github.com/clean-css/clean-css) — `MinimizerPlugin.cleanCssMinify`. A widely-used CSS optimiser. Requires `npm install --save-dev clean-css`.
- [`esbuild`](https://github.com/evanw/esbuild) — `MinimizerPlugin.esbuildMinifyCss`. Very fast CSS minification using esbuild's CSS loader. Requires `npm install --save-dev esbuild`.
- [`lightningcss`](https://github.com/parcel-bundler/lightningcss) — `MinimizerPlugin.lightningCssMinify`. A Rust-based CSS parser, transformer, and minifier. Requires `npm install --save-dev lightningcss`.
- [`@swc/css`](https://github.com/swc-project/swc) — `MinimizerPlugin.swcMinifyCss`. A very fast Rust-based CSS minifier. Requires `npm install --save-dev @swc/css`.

Image minimizers:

- [`sharp`](https://github.com/lovell/sharp) — `MinimizerPlugin.sharpMinify`. Re-encodes an image as the format its name already claims (`avif`, `gif`, `heif`, `jp2`, `jpeg`, `png`, `tiff`, `webp`), and can resize, rotate, flip, grayscale, blur or sharpen on the way — from the options or from the asset's own name. Requires `npm install --save-dev sharp`.
- [`svgo`](https://github.com/svg/svgo) — `MinimizerPlugin.svgoMinify`. Minifies SVG, including an `asset/inline` or `asset/source` SVG that no `test` can match. Requires `npm install --save-dev svgo`.
- [`imagemin`](https://github.com/imagemin/imagemin) — `MinimizerPlugin.imageminMinify`. Runs the `imagemin` plugins you name. Requires `npm install --save-dev imagemin` plus each plugin. Pair it with `MinimizerPlugin.imageminGenerate` under [`generate`](#generate) when a plugin converts the format, since only that can rename the asset.
- [`@napi-rs/image`](https://github.com/Brooooooklyn/Image) — `MinimizerPlugin.napiRsImageMinify`. Rust codecs with no system dependency; recompresses `png` losslessly with oxipng and `jpeg` with mozjpeg, and can resize, turn, mirror, grayscale, invert or blur on the way — from the options or from the asset's own name. Requires `npm install --save-dev @napi-rs/image`.

These only minify — they never change an image's format or name; see
[Images](#images).

Transport encodings:

- `zlib` and anything shaped like it — `MinimizerPlugin.compress`. Compresses an
  asset so a server can serve it under `Content-Encoding`. Takes `algorithm` — a
  `zlib` function's name (`gzip`, `brotliCompress`, `deflate`, `zstdCompress`, …)
  or one of your own — and `compressionOptions` for it, and needs no extra
  dependency. Give it to [`minify`](#minify) to compress an asset **in place**,
  or to [`generate`](#generate) as an `asset` generator to write the compressed
  file **beside** the original; either way it puts itself after the minimizers,
  through a `getStage` of its own.

All of the non-default minimizers are declared as **optional** peer
dependencies — install only the ones you actually use. One plugin instance
covers several languages at once: give [`minify`](#minify) an array and each
minimizer is offered only the assets its own `filter` accepts, so JS, CSS,
HTML and JSON share a single worker pool (see [Examples](#examples)).

## Getting Started

Webpack v5 comes with the latest `minimizer-webpack-plugin` out of the box.
If you are using Webpack v5 or above and wish to customize the options, you will still need to install `minimizer-webpack-plugin`.
Using Webpack v4, you have to install `terser-webpack-plugin` v4 (`minimizer-webpack-plugin` is only published for Webpack v5+).

To begin, you'll need to install `minimizer-webpack-plugin`:

```console
npm install minimizer-webpack-plugin --save-dev
```

or

```console
yarn add -D minimizer-webpack-plugin
```

or

```console
pnpm add -D minimizer-webpack-plugin
```

Then add the plugin to your `webpack` configuration. For example:

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [new MinimizerPlugin()],
  },
};
```

Finally, run `webpack` using the method you normally use (e.g., via CLI or an npm script).

## Note about source maps

**Works only with `source-map`, `inline-source-map`, `hidden-source-map` and `nosources-source-map` values for the [`devtool`](https://webpack.js.org/configuration/devtool/) option.**

Why?

- `eval` wraps modules in `eval("string")` and the minimizer does not handle strings.
- `cheap` has no column information and the minimizer generates only a single line, which leaves only a single mapping.

Using supported `devtool` values enable source map generation.

## Options

- **[`test`](#test)**
- **[`include`](#include)**
- **[`exclude`](#exclude)**
- **[`parallel`](#parallel)**
- **[`minify`](#minify)**
- **[`minimizerOptions`](#minimizeroptions)** (deprecated)
- **[`generate`](#generate)**
- **[`extractComments`](#extractcomments)**

### `test`

Type:

```ts
type test = string | RegExp | (string | RegExp)[];
```

Default: `/\.m?js(\?.*)?$/i`

Test to match files against.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.js(\?.*)?$/i,
      }),
    ],
  },
};
```

### `include`

Type:

```ts
type include = string | RegExp | (string | RegExp)[];
```

Default: `undefined`

Files to include.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        include: /\/includes/,
      }),
    ],
  },
};
```

### `exclude`

Type:

```ts
type exclude = string | RegExp | (string | RegExp)[];
```

Default: `undefined`

Files to exclude.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        exclude: /\/excludes/,
      }),
    ],
  },
};
```

### `parallel`

Type:

```ts
type parallel = boolean | number;
```

Default: `true`

Use multi-process parallel running to improve the build speed.

Default number of concurrent runs: `os.cpus().length - 1` or `os.availableParallelism() - 1` (if this function is supported).

> **Note**
>
> Parallelization can speedup your build significantly and is therefore **highly recommended**.

> **Warning**
>
> If you use **Circle CI** or any other environment that doesn't provide the real available count of CPUs then you need to explicitly set up the number of CPUs to avoid `Error: Call retries were exceeded` (see [#143](https://github.com/webpack/minimizer-webpack-plugin/issues/143), [#202](https://github.com/webpack/minimizer-webpack-plugin/issues/202)).

#### `boolean`

Enable/disable multi-process parallel running.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        parallel: true,
      }),
    ],
  },
};
```

#### `number`

Enable multi-process parallel running and set number of concurrent runs.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        parallel: 4,
      }),
    ],
  },
};
```

### `minify`

Type:

```ts
// The source map type webpack's `Source#map()` returns.
type RawSourceMap = Exclude<
  ReturnType<import("webpack").sources.Source["map"]>,
  null
>;

type minifyFn = (
  input: Record<string, string | Buffer>,
  sourceMap: RawSourceMap | undefined,
  minifyOptions: {
    module?: boolean | undefined;
    ecma?: import("terser").ECMA | undefined;
  },
  extractComments:
    | boolean
    | "all"
    | "some"
    | RegExp
    | ((
        astNode: any,
        comment: {
          value: string;
          type: "comment1" | "comment2" | "comment3" | "comment4";
          pos: number;
          line: number;
          col: number;
        },
      ) => boolean)
    | {
        condition?:
          | boolean
          | "all"
          | "some"
          | RegExp
          | ((
              astNode: any,
              comment: {
                value: string;
                type: "comment1" | "comment2" | "comment3" | "comment4";
                pos: number;
                line: number;
                col: number;
              },
            ) => boolean)
          | undefined;
        filename?: string | ((fileData: any) => string) | undefined;
        banner?:
          string | boolean | ((commentsFile: string) => string) | undefined;
      }
    | undefined,
) => Promise<{
  code: string;
  map?: RawSourceMap | undefined;
  errors?: (string | Error)[] | undefined;
  warnings?: (string | Error)[] | undefined;
  extractedComments?: string[] | undefined;
}>;

interface minimizer {
  implementation: minifyFn;
  options?: Record<string, any>;
}

type minify = minifyFn | (minifyFn | minimizer)[] | minimizer;
// An empty array is nothing to minify.
```

Default: `MinimizerPlugin.terserMinify`

Which minimizer runs, and the options it runs with. By default the plugin uses
[terser](https://github.com/terser/terser); overriding it is also how you test
an unpublished version or a fork. The default stands whether or not a
[`generate`](#generate) was configured too, and so does [`test`](#test)'s: the
JavaScript minifier and the names it reads are what this plugin is.

Nothing minifying is an **empty array** rather than a missing value, for an
instance whose whole job is its `generate`:

```js
new MinimizerPlugin({
  test: /.*/,
  minify: [],
  generate: {
    implementation: MinimizerPlugin.compress,
    options: { algorithm: "gzip" },
    type: "asset",
    filename: "[path][base].gz",
  },
});
```

`false` is not accepted. A list with nothing in it needs no guard at any of the
places that run the minimizers — each simply does nothing — while a second kind
of value does.

> **Warning**
>
> **Always use `require` inside `minify` function when `parallel` option enabled**.

#### `object`

The form to prefer: the minimizer and its own options in one place.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.swcMinify,
          options: { mangle: false },
        },
      }),
    ],
  },
};
```

`options` reaches the minify function as its third argument, and what it takes
is that minimizer's own: Terser's
[minify options](https://github.com/terser/terser#minify-options) for the
default one, and the tables in
[webpack's own minimizers](#webpacks-own-minimizers) for `cssMinify` and
`htmlMinify`.

`implementation` may also name a **module path** rather than hold the function
itself — a string, or `{ path, export }` for a named export, the way
`sass-loader` takes its `implementation`. A worker then `require`s the
minimizer, which is what the default terser is named by; one written as a
function is handed over as source for the worker to rebuild with `new
Function`:

```js
new MinimizerPlugin({
  minify: {
    // Or the string on its own, where the module exports the function itself.
    implementation: {
      path: require.resolve("./my-minifier"),
      export: "minify",
    },
  },
});
```

The saving is per task, so it needs every minimizer of that task to be nameable:
one written as a function anywhere in the list leaves the whole task on the
source path, since that function has no other way across. So does a function
anywhere in what the task carries — an `extractComments` callback, or a
minimizer's own options holding one — because a required minimizer is handed
the payload as it is, and a structured clone throws on a function.

`filter(name, info)` states which assets this minimizer is offered — return
`false` to decline one, and anything else (`undefined` included) to accept. It
answers for a `filter` property on the minimizer function itself, which is what
the built-ins carry, so setting it here is how you narrow one of them without
wrapping it.

```js
new MinimizerPlugin({
  minify: {
    implementation: MinimizerPlugin.sharpMinify,
    options: { encodeOptions: { jpeg: { quality: 80 } } },
    filter: (name) => !name.includes("do-not-touch"),
  },
});
```

Two keys are filled in before a minimizer sees them, and only when `options`
does not set them itself: `ecma`, from
[`output.environment`](https://webpack.js.org/configuration/output/#outputenvironment),
and `module`, from the asset's own `javascriptModule` info or its `.mjs` /
`.cjs` extension. Setting either yourself wins, including `module: false`.

<details>
<summary>The default minimizer's options, written out</summary>

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.terserMinify,
          options: {
            ecma: undefined,
            parse: {},
            compress: {},
            mangle: true, // Note `mangle.properties` is `false` by default.
            module: false,
            // Deprecated
            output: null,
            format: null,
            toplevel: false,
            nameCache: null,
            ie8: false,
            keep_classnames: undefined,
            keep_fnames: false,
            safari10: false,
          },
        },
      }),
    ],
  },
};
```

</details>

#### `array`

Several minimizers are an array of objects, rather than one object holding two
lists that have to line up. Each asset is dispatched to the minimizers whose
`filter` accepts it, and when more than one accepts the same asset the output
of each is fed to the next (the chain semantic). Warnings, errors and extracted
comments from all of them are merged.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: [
          {
            implementation: MinimizerPlugin.terserMinify,
            options: { mangle: false },
          },
          { implementation: MinimizerPlugin.swcMinify },
        ],
      }),
    ],
  },
};
```

Each entry carries its own `filter` as well as its own `options`, which is how
the same minimizer runs twice over different assets:

```js
new MinimizerPlugin({
  test: /\.(jpe?g|png)$/i,
  minify: [
    {
      implementation: MinimizerPlugin.sharpMinify,
      options: { encodeOptions: { jpeg: { quality: 60 } } },
      filter: (name) => name.includes("thumb"),
    },
    {
      implementation: MinimizerPlugin.sharpMinify,
      options: { encodeOptions: { jpeg: { quality: 90 } } },
      filter: (name) => !name.includes("thumb"),
    },
  ],
});
```

This is also what lets **one plugin instance and one worker pool** handle every
asset type: each built-in ships with a `filter` matching its natural
extension, so JS, CSS, HTML and JSON need no second instance. `test` still
defaults to JS only, so widen it to let the other assets reach the dispatcher:

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.(?:[cm]?js|css|html?|json)(\?.*)?$/i,
        minify: [
          { implementation: MinimizerPlugin.terserMinify },
          { implementation: MinimizerPlugin.cssnanoMinify },
          { implementation: MinimizerPlugin.htmlMinifierTerser },
          { implementation: MinimizerPlugin.jsonMinify },
        ],
      }),
    ],
  },
};
```

Pair it with [webpack's own](#webpacks-own-minimizers) `cssMinify` and
`htmlMinify` and the source a document or a stylesheet nests inside itself is
minified too — see [Embedded source](#embedded-source).

#### `function`

A bare function is shorthand for an object with no `options`. A custom one
says what it can do through properties on the function itself — each optional,
and each answering a question the plugin would otherwise have to guess at.

**webpack.config.js**

```js
// Can be async
const minify = (input, sourceMap, minimizerOptions, extractsComments) => {
  // Whatever the `minify` option's `options` holds reaches the third argument
  // You can use `minimizerOptions.myCustomOption`

  // Custom logic for extract comments
  const { map, code } = require("uglify-module") // Or require('./path/to/uglify-module')
    .minify(input, {/* Your options for minification */});

  return { map, code, warnings: [], errors: [], extractedComments: [] };
};

// Used to regenerate `fullhash`/`chunkhash` between different implementation
// Example: you fix a bug in custom minimizer/custom function, but unfortunately webpack doesn't know about it, so you will get the same fullhash/chunkhash
// to avoid this you can provide version of your custom minimizer
// You don't need if you use only `contenthash`
minify.getMinimizerVersion = () => {
  let packageJson;

  try {
    packageJson = require("uglify-module/package.json");
  } catch (error) {
    // Ignore
  }

  return packageJson && packageJson.version;
};

// Restrict the minimizer to the assets it can actually handle. The plugin
// skips assets for which `filter` returns `false` and (when an array of
// minimizers is used) dispatches each asset only to the minimizers that
// accept it. Returning `undefined` is treated as accept.
minify.filter = (name) => /\.[cm]?js(\?.*)?$/i.test(name);

// The languages this minimizer minifies. Source a module embeds in another
// language carries no filename, so `filter` cannot dispatch it and this does
// — a function without it is never handed any.
minify.getTypes = () => ["javascript"];

// Declare this when the minimizer reads the asset's bytes rather than its
// text — an image minimizer. Its `input` values then arrive as a `Buffer` and
// its `code` may be one. Only applied when every minimizer an asset is
// dispatched to declares it, since one that does not could not read the bytes.
minify.supportsBinary = () => true;

// Declare this when the minimizer has to run somewhere other than where
// minification does — it is handed the `Compilation` class so it can name a
// stage rather than a number. Each minimizer runs where it asks, chaining
// through the asset a later one reads back; one asking for nothing runs where
// minifying belongs.
minify.getStage = (compilation) =>
  compilation.PROCESS_ASSETS_STAGE_OPTIMIZE_TRANSFER;

// The name this function's work goes under: the asset it writes is marked
// with it in the asset info, and stats print it. A minimizer declaring
// nothing minified the asset, so `minimized`; a generator declaring nothing
// wrote a new file, so `generated`. It is also what is not run twice — an
// asset already marked with every name a function writes is declined, which
// is how one minified by a child compilation is left alone.
minify.getAssetFlag = () => "compressed";

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: minify,
          options: { myCustomOption: true },
        },
      }),
    ],
  },
};
```

A minifier that **nests other languages inside what it prints** — a document
with an inline `<style>`, a stylesheet with a `data:` URL — hands each nested
body out instead of minifying it itself. It declares which languages it can
offer, and the plugin passes `renderEmbeddedSource` in its options when
something else claims one of them:

```js
async function myHtmlMinify(input, sourceMap, minimizerOptions) {
  const [[, code]] = Object.entries(input);
  const { renderEmbeddedSource } = minimizerOptions;

  // Absent when nothing configured claims a language this minifier offers
  const minifyStyle = async (css) => {
    const result = renderEmbeddedSource
      ? await renderEmbeddedSource(css, { type: "css" })
      : undefined;

    // Declining leaves the body exactly as it was written
    return result && typeof result.code === "string" ? result.code : css;
  };

  return { code: await print(code, minifyStyle) };
}

// The languages this minifier can hand out, given the options it will run with
myHtmlMinify.getEmbeddedTypes = (minimizerOptions) => ["css", "javascript"];
```

`renderEmbeddedSource(source, { type, as })` answers
`{ code?, warnings?, errors? }` or `undefined`, and recurses — a body that
nests something of its own is reached too. `as` says which production of
`type` the body is; a `style=""` is `"block-contents"` rather than a whole
stylesheet. [Embedded source](#embedded-source) has the whole picture.

### `minimizerOptions`

> **Note**
>
> **Deprecated**, and to be removed in the next major release. Give a
> minimizer its options in [`minify`](#minify) instead, which keeps one
> minimizer's configuration in one place. It keeps working, and setting the
> options for one minimizer in both places is an error.

Type:

```ts
type minimizerOptions = Record<string, any> | Record<string, any>[];
```

Default: [Terser's](https://github.com/terser/terser#minify-options)

Options for the active minimizer, given away from it. With an array of
minimizers it may be an array too — each element goes to the minimizer at the
same index — or one object every minimizer is handed. It is still the only way
to configure the **default** minimizer without naming it:

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [new MinimizerPlugin({ minimizerOptions: { mangle: false } })],
  },
};
```

`terserOptions` is a deprecated alias of it — passing either is equivalent, and
`minimizerOptions` wins if both are set.

### `generate`

Type:

```ts
type generateFn = (
  input: Record<string, string | Buffer>,
  sourceMap: undefined,
  generatorOptions: Record<string, any>,
) => Promise<{
  code: string | Buffer;
  filename?: string;
  errors?: (Error | string)[];
  warnings?: (Error | string)[];
}>;

interface generator {
  implementation: generateFn;
  options?: Record<string, any>;
  type?: "import" | "asset";
  filename?: string | ((pathData: any) => string);
  filter?: (name: string) => boolean;
  deleteOriginalAssets?: boolean | ((name: string) => boolean);
  threshold?: number;
  minRatio?: number;
  relatedName?: string | false;
}

type generate =
  | generateFn
  | generateFn[]
  | generator
  | Record<string, generateFn | generateFn[] | generator>;
```

Default: `undefined`

Rewrites a module's own bytes **as it is built**, rather than an asset after
the build. That is the one point at which a re-encoding can also **rename** —
return a `filename` and the asset is emitted under it, with every reference in
the bundle following. [`minify`](#minify) cannot: an asset's name is decided
during code generation, so renaming there would leave the bundle pointing at a
URL nothing emits.

[`test`](#test), [`include`](#include) and [`exclude`](#exclude) select which
modules it sees, matched against the module's resource — query and all, so
`?as=webp` is matchable. A generator runs **in the webpack process**, since
modules build before the worker pool is up, and its answer is cached under the
bytes plus the generator and its options.

Two generators ship with the plugin, and they differ in who picks the format.
`sharpGenerate` is told: it takes the target from the request's `?as=` or,
failing that, from an `options.encodeOptions` naming exactly one format, and reports an error when neither says which format
to write. `imageminGenerate` is not: its plugins decide, so it reads the format
back off the bytes they produced and renames to match, leaving an asset its
plugins did not convert under the name it had.

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  module: {
    rules: [
      {
        test: /\.(jpe?g|png)$/i,
        type: "asset/resource",
        // The query has to survive into the name, or two formats of one image
        // collide.
        generator: { filename: "[name][ext][query]" },
      },
    ],
  },
  plugins: [
    new MinimizerPlugin({
      test: /\.(jpe?g|png)$/i,
      generate: MinimizerPlugin.sharpGenerate,
    }),
  ],
};
```

```js
// `image.jpg` is emitted as `image.webp`, and this import points at it.
import webp from "./image.jpg?as=webp";
```

Written as an object, `generate` **names** its generators, and an asset picks
one by name with `?as=`:

```js
new MinimizerPlugin({
  test: /\.(jpe?g|png)$/i,
  generate: {
    webp: {
      implementation: MinimizerPlugin.sharpGenerate,
      options: { encodeOptions: { webp: { quality: 90 } } },
    },
    avif: {
      implementation: MinimizerPlugin.sharpGenerate,
      options: { encodeOptions: { avif: { quality: 50 } } },
    },
  },
});
```

```js
// And `./image.jpg?as=avif` for the other one.
import webp from "./image.jpg?as=webp";
```

A module naming no preset is left alone, so the same build can import an image
unconverted. One naming a preset nothing defines is an error rather than a
silent decline, since the name it asked for is what the bundle would point at.

A generator can also be written as an object — on its own, or under a name —
which is where its own options live and what lets it read what was **emitted**
instead of a module as it builds:

```js
new MinimizerPlugin({
  test: /\.(jpe?g|png)$/i,
  generate: {
    webp: {
      implementation: MinimizerPlugin.sharpGenerate,
      options: { encodeOptions: { webp: {} } },
      type: "asset",
      // Optional, a template or a function answering with one. Without it the
      // generator's own name for the result is used, which for `sharpGenerate`
      // is the original with its extension replaced.
      filename: "[path][name].webp",
      // Optional. Narrows what this generator reads, on top of `test`.
      filter: (name) => !name.includes("icons/"),
      // Optional, `false` by default: the asset it read stays where it is.
      // Written as a function it is asked per asset.
      deleteOriginalAssets: false,
      // Optional. Skips an asset this small, before the generator is asked.
      threshold: 10240,
      // Optional. Drops the result unless it is this much smaller than what
      // it read, as `generated size / original size`.
      minRatio: 0.8,
      // Optional. The key the new file is recorded under in the original's
      // `related` info, which is how a server asked for one finds the other.
      relatedName: "webp",
    },
  },
});
```

`type` decides which of the two things a generator does, and they are not
interchangeable — they read different input, at different points in the build:

|                                | `"import"` (the default)                   | `"asset"`                                                                                       |
| :----------------------------- | :----------------------------------------- | :---------------------------------------------------------------------------------------------- |
| Reads                          | a module, **as it builds**                 | an asset, **once it is emitted**                                                                |
| Produces                       | that module's own bytes, renamed with them | a **new file beside** the one it read                                                           |
| Picked by                      | `?as=<name>` on the import                 | `test` / `include` / `exclude`, then `filter`                                                   |
| Reaches a file nothing imports | no                                         | yes — copied assets included                                                                    |
| Fields it reads                | `implementation`, `options`                | those plus `filename`, `filter`, `deleteOriginalAssets`, `threshold`, `minRatio`, `relatedName` |
| webpack                        | **5.111** or newer                         | any supported version                                                                           |

**`"import"`** is the only point at which a rename can reach the bundle: the
asset is named while its module is built, so every reference follows it. The
import that asked for the conversion gets the converted file.

```js
new MinimizerPlugin({
  test: /\.(jpe?g|png)$/i,
  generate: { webp: { implementation: MinimizerPlugin.sharpGenerate } },
});
```

```js
import url from "./photo.jpg?as=webp"; // url is "photo.webp"

const same = new URL("./photo.jpg?as=webp", import.meta.url); // photo.webp
```

```css
.hero {
  background: url("./photo.jpg?as=webp"); /* photo.webp */
}
```

```
photo.webp    the jpg became this
```

Those are one asset module between them, so an `import`, a `new URL()` and a
CSS `url()` all follow the rename. An asset inlined as a data URI carries no
file name, and takes the media type of what it became — `data:image/webp;…`.

**`"asset"`** leaves what it read alone and writes another file next to it, so
both survive — the `<picture>` case, where the `.webp` goes in a `srcset` you
write yourself and the `.jpg` stays as the fallback. Nothing imports the new
file, so `?as=` cannot reach it and its preset name selects nothing; the name
is only how you address its options. An asset already generated is never
generated from again.

```js
new MinimizerPlugin({
  test: /\.(jpe?g|png)$/i,
  generate: {
    webp: { implementation: MinimizerPlugin.sharpGenerate, type: "asset" },
  },
});
```

```js
import url from "./photo.jpg"; // url is "photo.jpg", unchanged
```

```
photo.jpg     still there, unless `deleteOriginalAssets`
photo.webp    generated beside it
```

`filename`, `filter`, `deleteOriginalAssets`, `threshold`, `minRatio` and
`relatedName` describe a file being written beside another, so they belong to
`"asset"` and setting one on an `"import"` generator is an error rather than a
field that quietly does nothing.

Three of them decide whether the new file is worth having. `threshold` skips an
asset too small to bother with, before the generator is asked at all. `minRatio`
drops a result that is not enough smaller than what it read, since a file that
saves nothing still costs a request. `relatedName` records the new file under
that key in the original's `related` info — which is how a server asked for the
original finds it — and declines an asset already carrying that key.

A file written under the original's own name has replaced it, so there is
nothing beside it to delete and nothing for `relatedName` to point at; a
generator doing that re-encodes an asset in place.

Deleting takes the original file and nothing else. webpack deletes whatever an
asset's `related` names along with it, so a source map, or the file a second
generator wrote beside the same original, would go too; the original goes
alone instead. Where the generated file took the original's own name there is
nothing left to delete, and `relatedName` is not recorded when the asset that
would carry it is being deleted.

A generated file inherits nothing from the one it was read from: what the
original's info says about its hashes, its module and where its source came
from is true of that file and not of this one. The exception is `immutable`,
and only where `filename` still derives from the original's name — `[name]`,
`[base]` or `[file]` — since that is what carried the hash the promise rests
on.

**When** a generator runs is not among them, because it is not the config's to
say: the implementation declares it through a `getStage` of its own, the way it
declares everything else about itself — see [`minify`](#minify). Compressing has
to read the bytes a user downloads, so `MinimizerPlugin.compress` asks for
`PROCESS_ASSETS_STAGE_OPTIMIZE_TRANSFER` and runs after every minimizer has had
its say; one that asks for nothing runs where minifying does. The **name its
work goes under** is the implementation's too, through the same kind of helper:
a generator declaring nothing wrote a new file, so `generated`, while `compress`
says `compressed`, another encoding of the bytes being no smaller a version of
them. Whatever the name, stats print it and the generator declines a file
already carrying it, so nothing reads its own output back.

`MinimizerPlugin.compress` ships with the plugin and is written against that.
`algorithm` says which compression to run — a `zlib` function's name, or one of
your own taking `(input, options, callback)` — and `compressionOptions` is what
that algorithm is run with, the way `terserMinify` takes terser's own options.
Here it is as an `asset` generator, which writes the compressed file beside the
one it read, so both survive and the URL says which is which:

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.(js|css|html|svg)$/i,
        generate: {
          gzip: {
            implementation: MinimizerPlugin.compress,
            options: { algorithm: "gzip" },
            type: "asset",
            filename: "[path][base].gz",
          },
          brotli: {
            implementation: MinimizerPlugin.compress,
            options: {
              algorithm: "brotliCompress",
              compressionOptions: { params: {} },
            },
            type: "asset",
            filename: "[path][base].br",
          },
        },
      }),
    ],
  },
};
```

Minifying and compressing are then one plugin over one pass of filtering and one
cache, and the ordering they need — compress what minification produced — is
what `stage` states rather than what applying two plugins in the right order
happens to give. Each algorithm is run at its own maximum by default (`zlib`'s
best level, brotli's best quality); name `compressionOptions` to say otherwise.

#### Compressing with minifying, and without

The example above does both: `minify` defaults to terser, so the bundle is
minified and the compressed files are written from what minification produced.
That is the shape to want — one pass of filtering, one cache, and `stage`
ordering the two — and it needs nothing said about `minify` at all:

```js
new MinimizerPlugin({
  test: /\.(js|css|html|svg)$/i,
  generate: {
    implementation: MinimizerPlugin.compress,
    options: { algorithm: "gzip" },
    type: "asset",
    filename: "[path][base].gz",
  },
});
```

Compressing **only** — an instance that must not touch what it reads — says so
with an empty list of minimizers. `test` is then yours to state too, since the
`.js` default belongs to minifying:

```js
new MinimizerPlugin({
  test: /.*/,
  minify: [],
  generate: {
    implementation: MinimizerPlugin.compress,
    options: { algorithm: "gzip" },
    type: "asset",
    filename: "[path][base].gz",
  },
});
```

Nothing is minified, no asset is marked `minimized`, and the bundle keeps the
name it would have had without this plugin — an instance that rewrites nothing
salts no hash.

It is an ordinary minimizer too, so [`minify`](#minify) takes it the way it
takes `terserMinify` or `swcMinify`. There it compresses the asset **in place**
rather than beside it — the shape for a server that says what the encoding is
through `Content-Encoding` while the URL stays as it was:

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.js$/i,
        minify: MinimizerPlugin.compress,
        minimizerOptions: { algorithm: "gzip" },
      }),
    ],
  },
};
```

An array runs its minimizers in order, each one reading what the last produced,
so minifying and then compressing in place is one entry after another — and each
states its own `options`. Each runs at the stage it asks for — terser before the
hash is taken, `compress` after — so `[contenthash]` still names what
minification produced:

```js
new MinimizerPlugin({
  test: /\.js$/i,
  minify: [
    { implementation: MinimizerPlugin.terserMinify },
    {
      implementation: MinimizerPlugin.compress,
      options: { algorithm: "brotliCompress" },
    },
  ],
});
```

`ecma` is filled in from
[`output.environment`](https://webpack.js.org/configuration/output/#outputenvironment)
unless a generator's options set it, the same way it is for a minimizer's —
see [`minify`](#minify).

`filename` is a
[webpack filename template](https://webpack.js.org/configuration/output/#outputfilename)
resolved against the asset read, so `[path]`, `[name]`, `[base]`, `[ext]` and
`[query]` are available; content hashes are not, because the name derives from
one the original already carries.

In watch mode the rename is carried on the module rather than reapplied each
build, so a rebuild that does not touch the image keeps pointing at the
generated name without running the generator again. Changing the image does
run it again, since its answer is cached under the bytes.

The same holds across runs under
[`cache.type: "filesystem"`](https://webpack.js.org/configuration/cache/#cachetype),
where a module is restored from the pack rather than rebuilt. That restored
result is the generator's, so changing a generator or its options has to
invalidate the pack, and the plugin adds their identity to
[`cache.version`](https://webpack.js.org/configuration/cache/#cacheversion) so
it does. This needs the plugin to be in the config — `plugins` or
`optimization.minimizer` — since webpack builds the cache while it applies
them; a plugin applied by hand after `webpack()` returns is too late to reach
it, and a changed generator would then be ignored until the cache directory is
removed.

> **Note**
>
> **Note**
>
> `generatorOptions` is kept as a deprecated way of giving a generator its
> options — one object for one generator, an array positionally matching an
> array of them, or keyed by name where `generate` names its generators. Prefer
> a generator's own `options`. Setting both for one generator is an error, and
> a key naming no generator is an error rather than silently doing nothing.

> **Note**
>
> An `"import"` generator needs a webpack whose `NormalModule` `processResult`
> hook can be awaited (**5.111** or newer), since that is where a rename has to
> happen. On an older webpack the plugin reports an error rather than silently
> generating nothing. An `"asset"` generator does not use that hook and works on
> any supported webpack.

### `extractComments`

Type:

```ts
type extractComments =
  | boolean
  | string
  | RegExp
  | ((
      astNode: any,
      comment: {
        value: string;
        type: "comment1" | "comment2" | "comment3" | "comment4";
        pos: number;
        line: number;
        col: number;
      },
    ) => boolean)
  | {
      condition?:
        | boolean
        | "all"
        | "some"
        | RegExp
        | ((
            astNode: any,
            comment: {
              value: string;
              type: "comment1" | "comment2" | "comment3" | "comment4";
              pos: number;
              line: number;
              col: number;
            },
          ) => boolean)
        | undefined;
      filename?: string | ((fileData: any) => string) | undefined;
      banner?:
        string | boolean | ((commentsFile: string) => string) | undefined;
    };
```

Default: `true`

Whether comments shall be extracted to a separate file, (see [details](https://github.com/webpack/webpack/commit/71933e979e51c533b432658d5e37917f9e71595a)).

By default, extract only comments using `/^\**!|@preserve|@license|@cc_on/i` RegExp condition and remove remaining comments.

If the original file is named `foo.js`, then the comments will be stored to `foo.js.LICENSE.txt`.

A minimizer's `options.format.comments` specifies whether the comment will be preserved - i.e., it is possible to preserve some comments (e.g. annotations) while extracting others, or even preserve comments that have already been extracted.

#### `boolean`

Enable/disable extracting comments.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: true,
      }),
    ],
  },
};
```

#### `string`

Extract `all` or `some` (use the `/^\**!|@preserve|@license|@cc_on/i` RegExp) comments.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: "all",
      }),
    ],
  },
};
```

#### `RegExp`

All comments that match the given expression will be extracted to a separate file.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: /@extract/i,
      }),
    ],
  },
};
```

#### `function`

All comments that match the given expression will be extracted to a separate file.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: (astNode, comment) => {
          if (/@extract/i.test(comment.value)) {
            return true;
          }

          return false;
        },
      }),
    ],
  },
};
```

#### `object`

Allows you to customize condition for extracting comments, and specify the extracted file name and banner.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: {
          condition: /^\**!|@preserve|@license|@cc_on/i,
          filename: (fileData) =>
            // The "fileData" argument contains object with "filename", "basename", "query" and "hash"
            `${fileData.filename}.LICENSE.txt${fileData.query}`,
          banner: (licenseFile) =>
            `License information can be found in ${licenseFile}`,
        },
      }),
    ],
  },
};
```

##### `condition`

Type:

```ts
type condition =
  | boolean
  | "all"
  | "some"
  | RegExp
  | ((
      astNode: any,
      comment: {
        value: string;
        type: "comment1" | "comment2" | "comment3" | "comment4";
        pos: number;
        line: number;
        col: number;
      },
    ) => boolean)
  | undefined;
```

The condition that determines which comments should be extracted.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: {
          condition: "some",
          filename: (fileData) =>
            // The "fileData" argument contains object with "filename", "basename", "query" and "hash"
            `${fileData.filename}.LICENSE.txt${fileData.query}`,
          banner: (licenseFile) =>
            `License information can be found in ${licenseFile}`,
        },
      }),
    ],
  },
};
```

##### `filename`

Type:

```ts
type filename = string | ((fileData: any) => string) | undefined;
```

Default: `[file].LICENSE.txt[query]`

Available placeholders: `[file]`, `[query]` and `[filebase]` (`[base]` for webpack 5).

The file where the extracted comments will be stored.

Default is to append the suffix `.LICENSE.txt` to the original filename.

> **Warning**
>
> We highly recommend using the `.txt` extension. Using `.js`/`.cjs`/`.mjs` extensions may conflict with existing assets, which leads to broken code.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: {
          condition: /^\**!|@preserve|@license|@cc_on/i,
          filename: "extracted-comments.js",
          banner: (licenseFile) =>
            `License information can be found in ${licenseFile}`,
        },
      }),
    ],
  },
};
```

##### `banner`

Type:

```ts
type banner = string | boolean | ((commentsFile: string) => string) | undefined;
```

Default: `/*! For license information please see ${commentsFile} */`

The banner text that points to the extracted file and will be added at the top of the original file.

It can be `false` (no banner), a `String`, or a `function<(string) -> String>` that will be called with the filename where the extracted comments have been stored.

The banner will be wrapped in a comment: `/*! … */` by default, or whatever the `minify` function's `formatBanner` helper returns. An HTML minimizer needs one, since a `/*!` line is text in a document:

```js
minify.formatBanner = (banner) => `<!-- ${banner} -->`;
```

The banner goes at the top of the asset; a `getBannerPosition` helper returning `"end"` appends it instead, which keeps a document's doctype first:

```js
minify.getBannerPosition = () => "end";
```

The source of both helpers is part of the cache key and the `[chunkhash]`, but not the values they close over: a helper whose output depends on such a value must make `getMinimizerVersion` change with it, or a rebuild reuses the earlier banner from the cache.

The asset's info records the banner as `licenseBanner`: `comment` is the comment as written, and `href` the URL it reaches the extracted file by — relative to the asset for the default banner, the name a custom banner was called with where its text holds it, and `undefined` otherwise. A tool that writes the asset's bytes into another file, such as a page inlining a script, replaces `href` within `comment` with the URL from where that file is.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        extractComments: {
          condition: true,
          filename: (fileData) =>
            // The "fileData" argument contains object with "filename", "basename", "query" and "hash"
            `${fileData.filename}.LICENSE.txt${fileData.query}`,
          banner: (commentsFile) =>
            `My custom banner about license information ${commentsFile}`,
        },
      }),
    ],
  },
};
```

## Embedded source

Source written in one language that reaches the bundle inside another is
minified too, which no asset carries and an asset-level minimizer therefore
never sees. It needs no option (webpack `>= 5.110.0`; older versions reach only
what an asset nests inside itself).

Such source has no filename, so `test` / `include` / `exclude` and each
minimizer's `filter` — all of which match filenames — cannot dispatch it.
**It is dispatched by the language it is written in**, which every minify
function states for itself:

```js
myCssMinifier.getTypes = () => ["css"];
```

webpack's own `cssMinify` and `htmlMinify` declare `css` and `html`, and are
the two that hand out what they nest. The built-ins declare `javascript`
(`terserMinify`, `uglifyJsMinify`, `swcMinify`, `esbuildMinify`), `css`
(`cssnanoMinify`, `cssoMinify`, `cleanCssMinify`, `esbuildMinifyCss`,
`lightningCssMinify`, `swcMinifyCss`), `html` (`htmlMinifierTerser`,
`swcMinifyHtml`, `swcMinifyHtmlFragment`, `minifyHtmlNode`) and `json`
(`jsonMinify`). A language **no configured minimizer
claims — `svg` out of the box — is emitted exactly as it was written**, and a
custom minify function without `getTypes` is never handed embedded source at
all.

What this reaches:

- CSS and HTML a module embeds in a JavaScript string literal (every
  `exportType` but `link`).
- The payload an `asset/inline` module encodes — the payload before it is
  encoded, so the encoding covers what came back. **A language written as text
  only**: an inline `svg` is offered, an inline `png` or `jpeg` is not, so a
  raster image that becomes a `data:` URI is minified by
  [`generate`](#generate) rather than here.
- The SVG an `asset/source` module embeds. Any other text import is data the
  program reads, so webpack embeds it as written: a minifier would change what
  the program reads, quotes and names included. Which text webpack offers
  depends on its version:
  - webpack 5.110 to 5.112 offers every language the file's name names.
  - webpack 5.113.0 offers none.
  - The release with
    [webpack/webpack#23500](https://github.com/webpack/webpack/pull/23500) and
    later offer SVG only.

  An `asset/resource` SVG is a file of its own, so it is minified as any asset
  is, when [`test`](#test) matches it.

- What a document or a stylesheet nests inside itself: an inline `<style>`,
  every `style=""`, a `<script>` holding JavaScript or JSON, an `<svg>` subtree,
  the document an `<iframe srcdoc>` holds, and the payload of a `url()` `data:`
  URL. This is how an inline `<script>` is minified by `terser` at all.

A `style=""` arrives as **`css` with `as: "block-contents"`** — the same word
`module.parser.css.as` uses. It holds a block's contents rather than a whole
stylesheet, so a minifier claiming `css` is handed one either way and `as` says
which it is. Ignore it at your peril: parsing a declaration list as a stylesheet
finds no rule and returns nothing.

A `<script type="module">` arrives the same way, as **`javascript` with
`as: "module"`**: JavaScript has two productions too, and a module script is one
wherever it sits. The built-in JavaScript minimizers read it as their own
`module` option, so the engine is never handed the word itself; a minify
function of your own claiming `javascript` is handed it and decides. Ignore it
at your peril: a module script read as a classic one is a syntax error the
moment it holds a top-level `await`.

An event handler attribute — `onclick=""` — arrives as **`javascript` with
`as: "event-handler"`**: its value is a function body, the production the
`return` cancelling an event is written in. No JavaScript engine here parses one
on its own, so each built-in minimizer minifies the function that body belongs
to and answers with the body back out of it. A minify function of your own is
handed the body as written and reads it however its engine can.

The nested case needs a minifier that can hand its nested bodies out, which it
also states for itself — webpack's `cssMinify` and `htmlMinify` do:

```js
// The languages this minifier can offer, given the options it will run with.
myHtmlMinifier.getEmbeddedTypes = (minimizerOptions) => ["css", "javascript"];
```

The option is passed only when **the two declarations meet**: if nothing
configured claims a language this minifier could offer, it is never handed one,
and minification is exactly what it always was. When it is, the nested bodies
are reached **in the same parse that prints** — the minifier leaves a marker
where each one goes and the answers are put in their place, so nothing is parsed
twice.

> **Note**
>
> Source a module embeds in JavaScript is minified during code generation,
> before the worker pool is up, so [`parallel`](#parallel) does not apply to it.
> What an asset nests inside itself is minified in the pool with the asset.

## Examples

### Preserve Comments

Extract all legal comments (i.e. `/^\**!|@preserve|@license|@cc_on/i`) and preserve `/@license/i` comments.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.terserMinify,
          options: { format: { comments: /@license/i } },
        },
        extractComments: true,
      }),
    ],
  },
};
```

### Remove Comments

If you want to build without comments, use this config:

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.terserMinify,
          options: { format: { comments: false } },
        },
        extractComments: false,
      }),
    ],
  },
};
```

### [`uglify-js`](https://github.com/mishoo/UglifyJS)

[`UglifyJS`](https://github.com/mishoo/UglifyJS) is a JavaScript parser, minifier, compressor and beautifier toolkit.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.uglifyJsMinify,
          // `options` will be passed to `uglify-js`
          // Link to options - https://github.com/mishoo/UglifyJS#minify-options
          options: {},
        },
      }),
    ],
  },
};
```

### [`swc`](https://github.com/swc-project/swc)

[`swc`](https://github.com/swc-project/swc) is a super-fast compiler written in `Rust`, producing widely supported JavaScript from modern standards and TypeScript.

> **Warning**
>
> `extractComments` is supported with `@swc/core >= 1.15.30`.
> Only serializable extract conditions are supported: booleans, `"some"`, `"all"`, string patterns, `RegExp` values without flags, or object conditions that resolve to those forms.
> Function conditions and flagged regular expressions are not supported.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.swcMinify,
          // `options` will be passed to `swc` (`@swc/core`)
          // Link to options - https://swc.rs/docs/config-js-minify
          options: {},
        },
      }),
    ],
  },
};
```

### [`esbuild`](https://github.com/evanw/esbuild)

[`esbuild`](https://github.com/evanw/esbuild) is an extremely fast JavaScript bundler and minifier.

> **Warning**
>
> The `extractComments` option is not supported, and all legal comments (i.e. copyright, licenses and etc) will be preserved.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.esbuildMinify,
          // `options` will be passed to `esbuild`
          // Link to options - https://esbuild.github.io/api/#minify
          // Note: the `minify` options is true by default (and override other `minify*` options), so if you want to disable the `minifyIdentifiers` option (or other `minify*` options) please use:
          // options: {
          //   minify: false,
          //   minifyWhitespace: true,
          //   minifyIdentifiers: false,
          //   minifySyntax: true,
          // },
          options: {},
        },
      }),
    ],
  },
};
```

### JSON

Uses `JSON.stringify()` to minify your JSON files during the build process.

**webpack.config.js**

```js
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      // Keeps original terser plugin to minify JS files
      "...",
      // Will minify JSON files (they can come from copy-webpack-plugin or when you are using asset modules)
      new MinimizerPlugin({
        test: /\.json$/,
        minify: {
          implementation: MinimizerPlugin.jsonMinify,
          // We are supporting `space` and `replacer` options, you can set them below
          options: {},
        },
      }),
    ],
  },
};
```

### HTML

The plugin can minify HTML assets too. Pick one of the bundled HTML
minimizers and set `test` to match your HTML files.

Available HTML minimizers:

- `webpack.html.syntax.htmlMinify` — webpack's own, shipped with webpack itself, so it needs no extra dependency. The one that can minify what a document nests — an inline `<style>`, a `<script>`, an `<svg>`. See [webpack's own minimizers](#webpacks-own-minimizers).
- `MinimizerPlugin.htmlMinifierTerser` — uses [`html-minifier-terser`](https://github.com/terser/html-minifier-terser).
- `MinimizerPlugin.swcMinifyHtml` — uses [`@swc/html`](https://github.com/swc-project/swc) for full HTML documents (with doctype and `<html>`/`<head>`/`<body>` tags).
- `MinimizerPlugin.swcMinifyHtmlFragment` — uses [`@swc/html`](https://github.com/swc-project/swc) for HTML fragments (e.g. content inside `<template></template>` or partial HTML strings).
- `MinimizerPlugin.minifyHtmlNode` — uses [`@minify-html/node`](https://github.com/wilsonzlin/minify-html).

The HTML minimizers are optional peer dependencies — install only the one
you actually use:

```console
npm install --save-dev html-minifier-terser
# or
npm install --save-dev @swc/html
# or
npm install --save-dev @minify-html/node
```

> **Note**
>
> HTML assets typically come from plugins like
> [`copy-webpack-plugin`](https://github.com/webpack-contrib/copy-webpack-plugin),
> [`html-webpack-plugin`](https://github.com/jantimon/html-webpack-plugin),
> or webpack's [asset modules](https://webpack.js.org/guides/asset-modules/).

> **Note**
>
> Whitespace handling differs between tools (defaults):
>
> - `@swc/html` — removes/collapses whitespace only in safe places (around `html`/`body`, inside `<head>`, between `<meta>`/`<script>`/`<link>` etc.).
> - `html-minifier-terser` — always collapses multiple whitespaces to a single space (never removes entirely); configurable via [its options](https://github.com/terser/html-minifier-terser#options-quick-reference).
> - `@minify-html/node` — see [its whitespace docs](https://github.com/wilsonzlin/minify-html#whitespace).

#### `html-minifier-terser`

[`html-minifier-terser`](https://github.com/terser/html-minifier-terser) is a JavaScript-based HTML minifier with no native dependency.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      // Keeps the default Terser plugin for JS files
      "...",
      new MinimizerPlugin({
        test: /\.html(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.htmlMinifierTerser,
          // Options - https://github.com/terser/html-minifier-terser#options-quick-reference
          options: {
            collapseWhitespace: true,
            removeComments: true,
          },
        },
      }),
    ],
  },
};
```

#### `@swc/html` — HTML documents

Use `swcMinifyHtml` for complete HTML documents (i.e. with a doctype and `<html>`/`<head>`/`<body>` tags).

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.html(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.swcMinifyHtml,
          // Options - https://github.com/swc-project/bindings/blob/main/packages/html/index.ts
          options: {},
        },
      }),
    ],
  },
};
```

#### `@swc/html` — HTML fragments

Use `swcMinifyHtmlFragment` for partial HTML — for example, content of `<template></template>` tags or HTML strings that get injected into another document.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.template\.html$/i,
        minify: {
          implementation: MinimizerPlugin.swcMinifyHtmlFragment,
          // Options - https://github.com/swc-project/bindings/blob/main/packages/html/index.ts
          options: {},
        },
      }),
    ],
  },
};
```

> **Note**
>
> The difference between `swcMinifyHtml` and `swcMinifyHtmlFragment` is the
> error reporting — invalid or broken syntax is reported at build time.

#### `@minify-html/node`

[`@minify-html/node`](https://github.com/wilsonzlin/minify-html) is a Rust HTML minifier.

**webpack.config.js**

```js
const Minimizer = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new Minimizer({
        test: /\.html(\?.*)?$/i,
        minify: {
          implementation: Minimizer.minifyHtmlNode,
          // Options - https://github.com/wilsonzlin/minify-html#minification
          options: {},
        },
      }),
    ],
  },
};
```

You can also stack multiple `MinimizerPlugin` instances to compress different files with different `minify` functions in the same build (e.g. JS with `terserMinify`, HTML with `htmlMinifierTerser`, JSON with `jsonMinify`).

### CSS

The plugin can minify CSS assets too. Pick one of the bundled CSS
minimizers and set `test` to match your CSS files.

Available CSS minimizers:

- `webpack.css.syntax.cssMinify` — webpack's own, shipped with webpack itself, so it needs no extra dependency. The one that can minify the CSS a document nests. See [webpack's own minimizers](#webpacks-own-minimizers).
- `MinimizerPlugin.cssnanoMinify` — uses [`cssnano`](https://cssnano.github.io/cssnano/) (via [`postcss`](https://postcss.org/)).
- `MinimizerPlugin.cssoMinify` — uses [`csso`](https://github.com/css/csso).
- `MinimizerPlugin.cleanCssMinify` — uses [`clean-css`](https://github.com/clean-css/clean-css).
- `MinimizerPlugin.esbuildMinifyCss` — uses [`esbuild`](https://github.com/evanw/esbuild) with the CSS loader.
- `MinimizerPlugin.lightningCssMinify` — uses [`lightningcss`](https://github.com/parcel-bundler/lightningcss).
- `MinimizerPlugin.swcMinifyCss` — uses [`@swc/css`](https://github.com/swc-project/swc).

The CSS minimizers are optional peer dependencies — install only the ones
you actually use:

```console
npm install --save-dev cssnano postcss
# or
npm install --save-dev csso
# or
npm install --save-dev clean-css
# or
npm install --save-dev esbuild
# or
npm install --save-dev lightningcss
# or
npm install --save-dev @swc/css
```

> **Note**
>
> CSS assets typically come from plugins like
> [`mini-css-extract-plugin`](https://github.com/webpack-contrib/mini-css-extract-plugin)
> or webpack's [asset modules](https://webpack.js.org/guides/asset-modules/).

#### `cssnano`

[`cssnano`](https://cssnano.github.io/cssnano/) runs as a [PostCSS](https://postcss.org/) plugin.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      // Keeps the default Terser plugin for JS files
      "...",
      new MinimizerPlugin({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.cssnanoMinify,
          // Options - https://cssnano.github.io/cssnano/docs/config-file/
          options: {
            preset: "default",
          },
        },
      }),
    ],
  },
};
```

#### `csso`

[`csso`](https://github.com/css/csso) is a CSS minifier with structural optimisations.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.cssoMinify,
          // Options - https://github.com/css/csso#minifysource-options
          options: {},
        },
      }),
    ],
  },
};
```

#### `clean-css`

[`clean-css`](https://github.com/clean-css/clean-css) is a widely-used CSS optimiser.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.cleanCssMinify,
          // Options - https://github.com/clean-css/clean-css#constructor-options
          options: {},
        },
      }),
    ],
  },
};
```

#### `esbuild`

[`esbuild`](https://github.com/evanw/esbuild) ships with a fast CSS minifier (used via its CSS loader).

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.esbuildMinifyCss,
          // Options - https://esbuild.github.io/api/#transform-api
          options: {},
        },
      }),
    ],
  },
};
```

#### `lightningcss`

[`lightningcss`](https://github.com/parcel-bundler/lightningcss) is a Rust-based CSS parser, transformer, and minifier.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.lightningCssMinify,
          // Options - https://lightningcss.dev/transpilation.html
          options: {},
        },
      }),
    ],
  },
};
```

#### `@swc/css`

[`@swc/css`](https://github.com/swc-project/swc) is a Rust-based CSS minifier.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.swcMinifyCss,
          // Options - https://github.com/swc-project/bindings/blob/main/packages/css/index.ts
          options: {},
        },
      }),
    ],
  },
};
```

### webpack's own minimizers

webpack ships a CSS and an HTML minimizer of its own. They need no extra
dependency — if you have webpack, you have them — and they are the two that
can hand out what a document or a stylesheet nests inside itself, so pairing
them with `terserMinify` and `jsonMinify` is what minifies embedded source
(see [Embedded source](#embedded-source)). They are reached through webpack's
public `css.syntax` and `html.syntax` exports, and need **webpack 5.111.0 or
newer**.

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");
const { cssMinify } = require("webpack").css.syntax;
const { htmlMinify } = require("webpack").html.syntax;

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.(?:[cm]?js|css|html|json)(\?.*)?$/i,
        minify: [
          { implementation: MinimizerPlugin.terserMinify },
          { implementation: cssMinify },
          { implementation: htmlMinify },
          { implementation: MinimizerPlugin.jsonMinify },
        ],
      }),
    ],
  },
};
```

Each one dispatches itself, so `test` only has to be wide enough to let the
assets through: `cssMinify` claims `*.css` and `htmlMinify` claims `*.html`
through their own `filter`, and both run in the worker pool.

|                           | `cssMinify`                                | `htmlMinify`                               |
| :------------------------ | :----------------------------------------- | :----------------------------------------- |
| `getTypes()`              | `css`                                      | `html`                                     |
| `getEmbeddedTypes()`      | `svg`, `css`, `html`, `json`, `javascript` | `css`, `javascript`, `json`, `svg`, `html` |
| `filter`                  | `/\.css(\?.*)?$/i`                         | `/\.html(\?.*)?$/i`                        |
| `supportsWorkerThreads()` | `true`                                     | `true`                                     |

Their `options` are `optimization.minimize.css` and
`optimization.minimize.html` respectively. `environment` carries what the
target can read (`{ browsers, vendorPrefixes }`, the CSS entries of
[`output.environment`](https://webpack.js.org/configuration/output/#outputenvironment)),
so a spelling the target could not parse is never reached for.

#### `cssMinify` options

Every option is named directly on the object — the per-transform switches sit
beside the rest, not nested.

| Option                    | Type                                                | Default        | What it does                                                                                                                          |
| :------------------------ | :-------------------------------------------------- | :------------- | :------------------------------------------------------------------------------------------------------------------------------------ |
| `environment`             | `{ browsers?: string[], vendorPrefixes?: boolean }` | —              | What the target can read. `browsers` is a browserslist selection; `vendorPrefixes: false` leaves prefixes alone.                      |
| `as`                      | `"stylesheet" \| "block-contents"`                  | `"stylesheet"` | Which production to read the source as. The plugin sets it — a `style=""` arrives as `"block-contents"`.                              |
| `convertLengthUnits`      | `boolean`                                           | `false`        | Rewrite a length into a shorter unit it is exactly equal in (`16px` → `1pc`). Off because it earns nothing once compressed.           |
| `rewriteCustomProperties` | `boolean`                                           | `false`        | Shorten a custom property's value like any other (`--x:#ffffff` → `--x:#fff`). Off because `getPropertyValue()` hands that text back. |
| `unusedSymbols`           | `string[]`                                          | —              | Names a whole-project analysis found unused; a bare name is a class, id or `@keyframes`, a `--`-prefixed one a custom property.       |
| `pseudoClasses`           | `{ [name: string]: string }`                        | —              | Write a pseudo-class as a class instead, so a script can apply it where the engine does not.                                          |
| `renderEmbeddedSource`    | function                                            | —              | **Owned by the plugin** — do not pass it.                                                                                             |

Per-transform switches, each on unless set to `false`:

| Switch                 | What it rewrites                                                                                                         |
| :--------------------- | :----------------------------------------------------------------------------------------------------------------------- |
| `colorFallbacks`       | Writes a color the target cannot read as an extra declaration before it, in a spelling it does read.                     |
| `lowerUnsupported`     | Writes a spelling the target cannot read as one it can — the same value, said another way.                               |
| `foldCase`             | Lowercases a name that matches ASCII case-insensitively (at-rule, property, pseudo, function, unit, keyword).            |
| `rewriteEscapes`       | Writes an escaped identifier the shortest way that names it.                                                             |
| `comments`             | Which comments survive: `"some"` (default), `true` / `"all"`, `false`, or a pattern / predicate over the comment's text. |
| `resolveCustomAtRules` | Inlines what `@custom-media` / `@custom-selector` names, and drops the rule that named it.                               |
| `mergeLonghands`       | Writes a family of longhands as the one shorthand that sets them.                                                        |
| `mergeRules`           | Joins rules printing the same block, at-rules sharing a prelude, and a `@layer` block a later sibling reopens.           |
| `normalizeQuotes`      | Normalizes quoting of strings, `url()`, font families and attribute values.                                              |
| `reduceFunctions`      | Computes a call into the shorter call naming the same value (`calc()`, transforms, gradients, easings, filters).         |
| `removeDeadRules`      | Drops a rule or declaration nothing can read — an empty rule, one an identical later one supersedes.                     |
| `rewriteDirSelector`   | Writes a `:dir()` the target cannot read as the `[dir]` attribute selector.                                              |
| `shortenColors`        | Writes each color in the shortest spelling of the same value.                                                            |
| `shortenMediaQueries`  | Writes a media feature in its range spelling and collapses an `and` of two into the interval.                            |
| `shortenNumbers`       | Writes each number in its shortest equal spelling.                                                                       |
| `shortenSelectors`     | Rewrites a selector into a shorter equal one.                                                                            |
| `shortenValues`        | Writes a value the shortest way its property's own grammar allows.                                                       |

#### `htmlMinify` options

| Option                      | Type                                            | Default   | What it does                                                                                                                                                     |
| :-------------------------- | :---------------------------------------------- | :-------- | :--------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `environment`               | same as `cssMinify`                             | —         | CSS's, not HTML's: handed to the CSS minifier this runs over inline CSS.                                                                                         |
| `css`                       | object                                          | `{}`      | The CSS minifier's options for that inline CSS — see below.                                                                                                      |
| `collapseWhitespace`        | `boolean \| "conservative" \| "smart" \| "all"` | `false`   | Collapses each run of whitespace in text, except where an ancestor renders it verbatim; `"smart"` also drops what sits against a block edge, `"all"` every edge. |
| `removeEmptyAttributes`     | `boolean`                                       | `false`   | Drops an attribute whose empty value leaves it in the state its absence gives.                                                                                   |
| `removeEmptyElements`       | `boolean`                                       | `false`   | Drops an element with no children and no attributes, unless its bare form is meaningful.                                                                         |
| `mergeStyles`               | `boolean`                                       | `false`   | Prints a run of adjacent `<style>` elements as one sheet.                                                                                                        |
| `sortAttributes`            | `boolean`                                       | `false`   | Prints attributes commonest name first, ties by name — nothing in HTML reads the order.                                                                          |
| `sortTokenLists`            | `boolean`                                       | `false`   | Prints every token list the DOM reads as a set (`class`, `rel`, `part`, …) in token order.                                                                       |
| `removeRedundantAttributes` | `boolean \| "smart" \| "all"`                   | `false`   | Drops an attribute whose value is the element's own default; `"all"` also drops spec defaults a selector can match.                                              |
| `removeImpliedTags`         | `boolean \| "smart" \| "all"`                   | `"smart"` | How much of the `<html>` / `<head>` / `<body>` shell may be left out: `"smart"` only the `<html>` start tag, `true` / `"all"` all six.                           |
| `minifyConditionalComments` | `boolean`                                       | `false`   | Minifies the markup inside a conditional comment's body.                                                                                                         |
| `renderEmbeddedSource`      | function                                        | —         | **Owned by the plugin** — do not pass it.                                                                                                                        |

Per-transform switches, each on unless set to `false`:

| Switch                          | What it rewrites                                                                                                  |
| :------------------------------ | :---------------------------------------------------------------------------------------------------------------- |
| `collapseBooleanAttributes`     | Writes a boolean attribute spelled with its own name (`disabled="disabled"`) as the bare name.                    |
| `comments`                      | Which comments survive — same values as CSS's. One a parser or server reads is kept regardless.                   |
| `normalizeAttributeQuotes`      | Drops or re-picks an attribute value's quotes.                                                                    |
| `normalizeEnumeratedAttributes` | Folds an enumerated value to the keyword it names.                                                                |
| `normalizeListAttributes`       | Normalizes a space-, comma- or descriptor-separated list (`class`, `rel`, `srcset`, `sizes`, viewport `content`). |
| `normalizeNumericAttributes`    | Writes an integer attribute the one way its rules read it.                                                        |
| `removeOptionalTags`            | Leaves out an optional tag other than the shell, which is `removeImpliedTags`.                                    |

The `css` object takes the CSS minifier's `convertLengthUnits`,
`rewriteCustomProperties`, `unusedSymbols` and `pseudoClasses`, plus the CSS
per-transform switches. `environment` is **not** among them: `htmlMinify` runs
the CSS minifier over every inline `<style>` and `style=""`, so `environment`
stays **top level**, shared by the document and the CSS inside it. Give the two
minimizers the same `environment` and a `.css` asset and the same declaration
inline agree about the target:

```js
const environment = { browsers: ["chrome 100", "safari 15"] };

const options = [
  {},
  // cssMinify
  { environment, convertLengthUnits: true },
  // htmlMinify — `environment` reaches the CSS it nests; `css` carries the rest
  { environment, css: { convertLengthUnits: true } },
  {},
];
```

> **Note**
>
> Do not pass `renderEmbeddedSource` yourself. The plugin owns that option: it
> wires the minimizers to each other with it, and a value you set is replaced.
> What a minimizer offers and what another claims is what routes embedded
> source — see [Embedded source](#embedded-source).

Both minimizers re-resolve `webpack` when they run, in the worker pool as well
as in the main process, so the `webpack` resolvable from this plugin has to be
the one they came from, and at least **5.111.0** — the release that exports them
on `webpack.css.syntax` and `webpack.html.syntax`. On an older webpack the
destructure above yields `undefined`; a second or older copy in the tree
surfaces from inside the minifier as:

```
Cannot destructure property 'SourceProcessor' of 'webpack.css.syntax' as it is undefined.
Cannot destructure property 'askEmbeddedRenderer' of 'webpack.html.syntax' as it is undefined.
```

Deduplicate webpack (`npm dedupe`, or a single version in a workspace root) and
it goes away.

### Images

The plugin can minify image assets too. Pick one of the bundled image
minimizers and set `test` to match your images.

Available image minimizers:

- `MinimizerPlugin.sharpMinify` — uses [`sharp`](https://github.com/lovell/sharp), re-encoding each image as its own format.
- `MinimizerPlugin.svgoMinify` — uses [`svgo`](https://github.com/svg/svgo).
- `MinimizerPlugin.imageminMinify` — uses [`imagemin`](https://github.com/imagemin/imagemin) and the plugins you name.
- `MinimizerPlugin.napiRsImageMinify` — uses [`@napi-rs/image`](https://github.com/Brooooooklyn/Image), which ships prebuilt codecs.

Converting an image to another format is [`generate`](#generate)'s job rather
than a minimizer's, since only that can rename the asset:
`MinimizerPlugin.sharpGenerate` and `MinimizerPlugin.imageminGenerate`.

The image minimizers are optional peer dependencies — install only the ones
you actually use:

```console
npm install --save-dev sharp
# or
npm install --save-dev svgo
# or
npm install --save-dev imagemin imagemin-mozjpeg imagemin-pngquant
```

> **Note**
>
> On `minify` these **only minify** — they never change an image's format or
> name. An asset's name is decided during code generation, long before a
> minimizer runs, so a renamed asset would leave the bundle pointing at a URL
> nothing emits. Converting `.png` to `.webp` is what [`generate`](#generate)
> is for: it runs while the module builds, early enough to rename.

> **Note**
>
> `sharp` and `imagemin` read the asset's bytes rather than its text, so they
> run in the webpack process rather than in the worker pool — they do their own
> threading. Minimizers configured beside them keep the pool.

#### Images that never become files

`minify` runs over emitted assets, so an image that becomes a `data:` URI
instead of a file — `asset/inline`, or `asset` under
[`Rule.parser.dataUrlCondition`](https://webpack.js.org/configuration/module/#ruleparserdataurlcondition)
— never reaches it. An SVG is the exception, since it is text and webpack
offers it as [embedded source](#embedded-source).

Put the same minimizer under [`generate`](#generate) and it does reach one: a
generator runs while the module builds, over the bytes themselves, before
anything encodes them. It renames nothing unless it answers with a name, so a
minimizer stays a minimizer there.

```js
new MinimizerPlugin({
  test: /\.(jpe?g|png)$/i,
  generate: { implementation: MinimizerPlugin.sharpMinify },
});
```

Do not list the same image minimizer in both for the same assets — an emitted
one would then be re-encoded twice, which costs time and, for a lossy format,
quality. `generate` covers inlined and emitted images alike; `minify` is the
one to keep when nothing is inlined, since it runs after the whole build and
caches per asset. An `"import"` generator needs **webpack 5.111 or newer**.

#### Lossless and lossy

Images are optimized in one of two modes:

1. [Lossless](https://en.wikipedia.org/wiki/Lossless_compression) — the decoded
   pixels come back identical, only the encoding is made smaller.
2. [Lossy](https://en.wikipedia.org/wiki/Lossy_compression) — quality is traded
   for a smaller file.

**Which one you get with no `encodeOptions` at all**, measured by decoding the
output back to pixels and comparing it with the input:

| Format | `sharpMinify` | `napiRsImageMinify` |
| ------ | ------------- | ------------------- |
| `avif` | lossy         | lossy               |
| `gif`  | lossy         | not handled         |
| `jpeg` | lossy         | **lossless**        |
| `png`  | **lossless**  | **lossless**        |
| `tiff` | lossy         | not handled         |
| `webp` | lossy         | lossy               |

So `sharpMinify` is lossy by default everywhere except PNG — it re-encodes at
`sharp`'s own defaults, which are quality settings rather than lossless ones.
`napiRsImageMinify` is lossless by default for both PNG and JPEG, because those
two are repacked in place by oxipng and mozjpeg, rewriting the encoded bytes
rather than decoding to pixels and encoding again.

`svgoMinify` rewrites markup rather than pixels. It is lossless in the sense
that the rendered image is meant to be unchanged, but its default plugin preset
does rewrite paths and drop metadata — see
[`svgo`](https://github.com/svg/svgo#configuration) for which of those to turn
off.

`imageminMinify` is whatever its plugins are. `imagemin-jpegtran`,
`imagemin-optipng` and `imagemin-gifsicle` are lossless; `imagemin-mozjpeg` and
`imagemin-pngquant` are lossy. `imagemin-svgo` can be either.

**Asking `sharpMinify` for lossless output**

```js
new MinimizerPlugin({
  test: /\.(png|jpe?g|webp|avif)(\?.*)?$/i,
  minify: {
    implementation: MinimizerPlugin.sharpMinify,
    options: {
      encodeOptions: {
        // https://sharp.pixelplumbing.com/api-output
        jpeg: { quality: 100 },
        webp: { lossless: true },
        avif: { lossless: true },
        // PNG is already lossless at sharp's defaults
        png: {},
      },
    },
  },
});
```

**Asking `napiRsImageMinify` for lossy output**, which is where the savings are:

```js
new MinimizerPlugin({
  test: /\.(png|jpe?g|webp|avif)(\?.*)?$/i,
  minify: {
    implementation: MinimizerPlugin.napiRsImageMinify,
    options: {
      encodeOptions: {
        // Anything below 100 re-encodes rather than repacking
        jpeg: { quality: 80 },
        webp: { quality: 80 },
        avif: { quality: 70 },
        // `png` has no quality setting — it is lossless either way
      },
    },
  },
});
```

> **Note**
>
> Lossless does not mean "no smaller". On this repository's own PNG fixture
> `napiRsImageMinify` returns 59% of the original size without touching a
> single pixel, and `sharpMinify` returns 92%.

#### `sharp`

[`sharp`](https://github.com/lovell/sharp) re-encodes each image as the format
its name already claims, so a `.png` stays a PNG. It handles `avif`, `gif`,
`heif`, `jp2`, `jpeg`, `png`, `tiff` and `webp`.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      // Keeps the default Terser plugin for JS files
      "...",
      new MinimizerPlugin({
        test: /\.(png|jpe?g|webp|avif|tiff?|gif)$/i,
        minify: {
          implementation: MinimizerPlugin.sharpMinify,
          options: {
            // Options are keyed by sharp's format name
            // https://sharp.pixelplumbing.com/api-output
            encodeOptions: {
              jpeg: { quality: 80 },
              png: { compressionLevel: 9 },
              webp: { lossless: true },
            },
          },
        },
      }),
    ],
  },
};
```

`sharp` can also transform the image while it re-encodes:

```js
new MinimizerPlugin({
  test: /\.(png|jpe?g)$/i,
  minify: {
    implementation: MinimizerPlugin.sharpMinify,
    options: {
      // `enabled` and `unit` ("px" by default, or "percent") are read here;
      // everything else goes to sharp
      // https://sharp.pixelplumbing.com/api-resize
      resize: { width: 800, unit: "px", fit: "inside" },
      // A number of degrees, or "auto" to follow the EXIF orientation
      rotate: "auto",
      flip: false,
      flop: false,
      grayscale: false,
      // A sigma, or true for a fast default
      blur: false,
      sharpen: false,
      encodeOptions: { jpeg: { quality: 80 } },
    },
  },
});
```

Each of these can also be asked for by an asset's own name — see
[Query strings in asset names](#query-strings-in-asset-names).

#### `svgo`

[`svgo`](https://github.com/svg/svgo) minifies SVG. It also reaches an
`asset/inline` SVG — one that becomes a `data:` URI rather than a file — which
carries no asset name for `test` to match; see
[Embedded source](#embedded-source).

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.svg(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.svgoMinify,
          options: {
            // Options - https://github.com/svg/svgo#configuration
            encodeOptions: {
              multipass: true,
              plugins: ["preset-default"],
            },
          },
        },
      }),
    ],
  },
};
```

#### `imagemin`

[`imagemin`](https://github.com/imagemin/imagemin) runs the plugins you name.
Each is a string — `"mozjpeg"` resolves `imagemin-mozjpeg` — or a
`[name, options]` pair. Install each plugin yourself.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.(png|jpe?g|gif|svg)$/i,
        minify: {
          implementation: MinimizerPlugin.imageminMinify,
          options: {
            plugins: [
              "gifsicle",
              "mozjpeg",
              ["pngquant", { quality: [0.6, 0.8] }],
              "svgo",
            ],
          },
        },
      }),
    ],
  },
};
```

> **Note**
>
> A plugin that converts — `imagemin-webp`, `imagemin-avif` — writes a format
> the asset's name does not claim. `imageminMinify` keeps the original and
> warns instead of writing it, since it cannot rename the asset. Reach for
> [`generate`](#generate) with `MinimizerPlugin.imageminGenerate` to convert:
> it runs the same plugins while the module builds, which is where the asset
> can still take the name of the format they wrote.

#### `@napi-rs/image`

[`@napi-rs/image`](https://github.com/Brooooooklyn/Image) is a set of Rust
codecs shipped as prebuilt binaries, so it needs no system library. It handles
`avif`, `jpeg`, `png` and `webp` — the formats it both reads back reliably and
makes smaller.

Each format is re-encoded as itself, using the codec that does that best:
`png` goes through [oxipng](https://github.com/shssoichiro/oxipng), which
rewrites the container losslessly and leaves the pixels untouched, and `jpeg`
through [mozjpeg](https://github.com/mozilla/mozjpeg). Decoding either to
pixels and re-encoding saves a small fraction as much.

**webpack.config.js**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      "...",
      new MinimizerPlugin({
        test: /\.(png|jpe?g|webp|avif)$/i,
        minify: {
          implementation: MinimizerPlugin.napiRsImageMinify,
          options: {
            // Options are keyed by the format's own name
            // https://github.com/Brooooooklyn/Image#usage
            encodeOptions: {
              // `PNGLosslessOptions`
              png: { force: true },
              // `JpegCompressOptions`
              jpeg: { quality: 80 },
              // `AvifConfig`
              avif: { quality: 70, speed: 4 },
              // The quality factor, 0-100
              webp: { quality: 80 },
            },
          },
        },
      }),
    ],
  },
};
```

> **Note**
>
> `png` is recompressed losslessly, so it takes no quality setting. Resizing
> and rotating are not exposed here — use [`sharp`](#sharp) for those.

#### Query strings in asset names

An asset keeps the query and fragment of the request that made it:
`output.assetModuleFilename` is `[hash][ext][query][fragment]` by default, so
`import icon from "./icon.svg?v=2"` is emitted as `<hash>.svg?v=2`.

`test`, `include` and `exclude` are read against both spellings — the whole name
and the name with the query and fragment stripped — so all three of these accept
that asset:

```js
test: /\.svg$/i; // names the file
test: /\.svg(\?.*)?$/i; // names the query form
test: /\?v=2$/; // names the query itself
```

`exclude` rejects on either spelling, so excluding by file name also excludes
the queried asset. Every built-in minimizer's own `filter` reads past the query
in the same way.

**Asking sharp for something from the import.** `sharpMinify` reads what to do
off the asset's name, so one image can be sized, turned or re-encoded where it
is imported rather than in the configuration:

```js
import banner from "./banner.png?width=320&quality=80";
```

| Query                 | Short  | Value                                         | What it does                                 |
| --------------------- | ------ | --------------------------------------------- | -------------------------------------------- |
| `width`               | `w`    | pixels, or `auto`                             | target width                                 |
| `height`              | `h`    | pixels, or `auto`                             | target height                                |
| `unit`                | `u`    | `px` (default) or `percent`                   | how `width` and `height` are read            |
| `fit`                 |        | `cover` (default), `contain`, `fill`, …       | what to do when both dimensions are given    |
| `position`            | `pos`  | `centre` (default), `right top`, `entropy`, … | where to crop from                           |
| `background`          | `bg`   | a colour                                      | what `contain` pads with                     |
| `without-enlargement` |        | flag                                          | never scale the image up                     |
| `rotate`              | `rot`  | degrees, or `auto`                            | turn by an angle, or by the EXIF orientation |
| `flip`                |        | flag                                          | mirror vertically                            |
| `flop`                |        | flag                                          | mirror horizontally                          |
| `grayscale`           | `gray` | flag                                          | drop the colour                              |
| `blur`                |        | sigma, or flag                                | blur                                         |
| `sharpen`             |        | sigma, or flag                                | sharpen                                      |
| `quality`             | `q`    | a number                                      | encode quality                               |
| `lossless`            |        | flag                                          | encode losslessly, where the format has one  |
| `effort`              |        | a number                                      | how hard the encoder tries                   |
| `progressive`         | `prog` | flag                                          | interlace, where the format has it           |

| Import                                        | What comes out                                 |
| --------------------------------------------- | ---------------------------------------------- |
| `./photo.jpg?w=64&h=64&fit=cover&pos=entropy` | a 64x64 thumbnail, cropped to the busiest part |
| `./photo.jpg?width=16&blur&quality=30`        | a tiny blurred placeholder                     |
| `./logo.png?width=50&unit=percent&grayscale`  | half-size and grey                             |

A **flag** is on when it is present — `?flip` — and reads `true`/`1`/`yes` the
same way, `false`/`0`/`no` the other. `greyscale` and `grey` spell `grayscale`,
`auto` on `width` or `height` drops one set in the minimizer's `options`, and a
parameter can be spelled in any case.

Every one of these can also be set in the minimizer's `options`; the name wins where
both say something, being the more specific of the two. `resize: { enabled:
false }` still turns resizing off entirely.

Two rules decide what happens to a value:

- **Its shape is checked here, and anything else is ignored.** An asset's name
  carries queries this plugin never put there, so `?v=2` must not become a
  resize — and neither does `?width=nonsense` or `?flip=maybe`.
- **Whether a well-formed value is one sharp accepts is sharp's to report**, and
  it answers per format: `effort` runs to 6 for webp and 9 for avif, `quality`
  starts at 0 for png and 1 for jpeg, and a colour is whatever it can parse. A
  value outside those fails the build with sharp's own message rather than being
  dropped silently. An option a format has no use for — `?lossless` on a jpeg —
  is simply ignored.

**`napiRsImageMinify` reads the same names**, as far as `@napi-rs/image` goes:
`width`/`w`, `height`/`h`, `fit` (`cover`, `fill`, `inside`), `filter`
(`nearest`, `triangle`, `catmull-rom`, `gaussian`, `lanczos3`), `rotate`/`rot`,
`flip`, `flop`, `grayscale`, `invert`, `blur`, `quality`/`q`, `lossless` and
`speed`. Three differences are worth knowing:

- **`rotate` takes a quarter turn**, not any angle — `90`, `180`, `270`, a
  negative or a multiple of those, or `auto` for the EXIF orientation. napi
  applies one orientation, so mirroring and a turn compose into it (`?flip&flop`
  is a half turn); asking for `auto` alongside an explicit turn warns, because
  only one of them can be applied.
- **Every value is checked here**, rather than left to the library as sharp's
  are. napi rejects an unknown `fit` without naming it, and answers a quality of
  150 by silently writing a _bigger_ file, so a value it would mishandle is
  dropped instead.
- **Transforming costs the repack.** This minimizer's advantage is rewriting
  encoded bytes — oxipng saves 99% of a png where decoding and re-encoding saves
  9% — so when a query makes a transform necessary, its output is handed back to
  the repack rather than replacing it. A `?rotate=auto` on an image whose EXIF
  asks for nothing skips the decode entirely.

**`svgoMinify` reads `precision`** (or `floatPrecision`, 0–10), **`multipass`**,
**`pretty`** and **`indent`**, so one SVG can be laid out readably or coarsened
without a second configuration:

```js
import icon from "./icon.svg?precision=1";
```

**`imageminMinify` reads nothing.** Its options are a list of already-configured
plugins, each with option names of its own, so there is no parameter a query
could set that would mean the same thing twice over.

> **Note**
>
> Two assets whose names differ only by their query would be written to the same
> file, and webpack refuses that. To emit several sizes of one image, give each
> its own file name **and** keep the query on the asset name:
>
> ```js
> module.exports = {
>   output: {
>     assetModuleFilename: (pathData) => {
>       const query = pathData.module.resourceResolveData.query || "";
>       const name = query.replace(/^\?/, "-").replace(/[=&]/g, "-");
>
>       return `[name]${name}[ext][query]`;
>     },
>   },
> };
> ```
>
> Without the trailing `[query]` the size is no longer on the name and nothing
> resizes; without the first half the two sizes collide.

> **Note**
>
> A query cannot pick a **format** on this path. Resizing needs no new name,
> which is why it works here; changing the format does, and `minify` runs after
> names are decided. Hand `?as=webp` to [`generate`](#generate) instead, which
> sees the module as it builds and can emit the new format under a new name.

#### Images beside everything else

`minify` takes an array, and each minimizer is offered only the assets its own
`filter` accepts, so one plugin instance can cover several languages at once:

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.(js|css|svg|png|jpe?g)$/i,
        minify: [
          { implementation: MinimizerPlugin.terserMinify },
          { implementation: MinimizerPlugin.cssnanoMinify },
          { implementation: MinimizerPlugin.svgoMinify },
          {
            implementation: MinimizerPlugin.sharpMinify,
            options: { encodeOptions: { png: { compressionLevel: 9 } } },
          },
        ],
      }),
    ],
  },
};
```

### Custom Minify Function

Override the default minify function - use `uglify-js` for minification.

**webpack.config.js**

```js
const minifyWithUglifyJs = (file, sourceMap, minimizerOptions) => {
  const uglifyJsOptions = { ...minimizerOptions };

  // The plugin fills these two in, and `uglify-js` rejects options it does not know
  delete uglifyJsOptions.ecma;
  delete uglifyJsOptions.module;

  if (sourceMap) {
    uglifyJsOptions.sourceMap = { content: sourceMap };
  }

  return require("uglify-js").minify(file, uglifyJsOptions);
};

// Which assets it is offered, and which language it minifies. Without
// `getTypes` it is never handed the JavaScript a document or a module embeds
minifyWithUglifyJs.filter = (name) => /\.[cm]?js(\?.*)?$/i.test(name);
minifyWithUglifyJs.getTypes = () => ["javascript"];

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: minifyWithUglifyJs,
          // https://github.com/mishoo/UglifyJS2#minify-options
          options: {/* your `uglify-js` package options */},
        },
      }),
    ],
  },
};
```

A minifier that nests other languages inside its own output hands each body
out with `renderEmbeddedSource` rather than minifying it itself — see
[`minify`](#minify) and [Embedded source](#embedded-source).

### Typescript

With default Terser minify function:

```ts
module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        minify: {
          implementation: MinimizerPlugin.terserMinify,
          options: { compress: true },
        },
      }),
    ],
  },
};
```

With built-in minify functions:

```ts
import { type JsMinifyOptions as SwcOptions } from "@swc/core";
import { type MinifyOptions as SwcCssOptions } from "@swc/css";
import {
  type FragmentOptions as SwcHtmlFragmentOptions,
  type Options as SwcHtmlOptions,
} from "@swc/html";
import { type OptionsOutput as CleanCssOptions } from "clean-css";
import { type Options as CssnanoOptions } from "cssnano";
import { type CompressOptions as CssoOptions } from "csso";
import { type TransformOptions as EsbuildOptions } from "esbuild";
import { type Options as HtmlMinifierTerserOptions } from "html-minifier-terser";
import { type TransformOptions as LightningCssOptions } from "lightningcss";
import { type MinifyOptions as TerserOptions } from "terser";
import { type MinifyOptions as UglifyJSOptions } from "uglify-js";

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin<SwcOptions>({
        minify: {
          implementation: MinimizerPlugin.swcMinify,
          options: {
            // `swc` options
          },
        },
      }),
      new MinimizerPlugin<UglifyJSOptions>({
        minify: {
          implementation: MinimizerPlugin.uglifyJsMinify,
          options: {
            // `uglif-js` options
          },
        },
      }),
      new MinimizerPlugin<EsbuildOptions>({
        minify: {
          implementation: MinimizerPlugin.esbuildMinify,
          options: {
            // `esbuild` options
          },
        },
      }),

      // Alternative usage:
      new MinimizerPlugin<TerserOptions>({
        minify: {
          implementation: MinimizerPlugin.terserMinify,
          options: {
            // `terser` options
          },
        },
      }),

      // HTML minimizers
      new MinimizerPlugin<HtmlMinifierTerserOptions>({
        test: /\.html(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.htmlMinifierTerser,
          options: {
            // `html-minifier-terser` options
          },
        },
      }),
      new MinimizerPlugin<SwcHtmlOptions>({
        test: /\.html(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.swcMinifyHtml,
          options: {
            // `@swc/html` options
          },
        },
      }),
      new MinimizerPlugin<SwcHtmlFragmentOptions>({
        test: /\.template\.html$/i,
        minify: {
          implementation: MinimizerPlugin.swcMinifyHtmlFragment,
          options: {
            // `@swc/html` fragment options
          },
        },
      }),

      // CSS minimizers
      new MinimizerPlugin<CssnanoOptions>({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.cssnanoMinify,
          options: {
            // `cssnano` options
          },
        },
      }),
      new MinimizerPlugin<CssoOptions>({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.cssoMinify,
          options: {
            // `csso` options
          },
        },
      }),
      new MinimizerPlugin<CleanCssOptions>({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.cleanCssMinify,
          options: {
            // `clean-css` options
          },
        },
      }),
      new MinimizerPlugin<EsbuildOptions>({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.esbuildMinifyCss,
          options: {
            // `esbuild` options (CSS loader)
          },
        },
      }),
      new MinimizerPlugin<LightningCssOptions>({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.lightningCssMinify,
          options: {
            // `lightningcss` options
          },
        },
      }),
      new MinimizerPlugin<SwcCssOptions>({
        test: /\.css(\?.*)?$/i,
        minify: {
          implementation: MinimizerPlugin.swcMinifyCss,
          options: {
            // `@swc/css` options
          },
        },
      }),
    ],
  },
};
```

## Migrating from `image-minimizer-webpack-plugin`

This plugin does what
[`image-minimizer-webpack-plugin`](https://github.com/webpack/image-minimizer-webpack-plugin)
did, for every asset type rather than images alone, so one plugin covers a
build instead of two. The options line up like this:

| `image-minimizer-webpack-plugin`   | here                                              |
| ---------------------------------- | ------------------------------------------------- |
| `minimizer`                        | [`minify`](#minify), same shape                   |
| `minimizer.implementation`         | `implementation` on that minimizer                |
| `minimizer.options`                | `options` on that minimizer                       |
| `minimizer.filter`                 | a `filter` on the minimizer itself                |
| `generator[].implementation`       | [`generate`](#generate)                           |
| `generator[].options`              | `options` on that generator                       |
| `generator[].preset`               | the key the generator is written under            |
| `generator[].type`                 | `type` on that generator                          |
| `generator[].filename` / `.filter` | `filename` / `filter` on that generator           |
| `deleteOriginalAssets`             | `deleteOriginalAssets` on that generator          |
| `concurrency`                      | [`parallel`](#parallel)                           |
| `test` / `include` / `exclude`     | unchanged                                         |
| `loader`                           | nothing — `generate` reaches a module without one |
| `severityError`                    | nothing — a failed minimizer is an error          |

The minimizers and generators keep their names —
`imageminMinify`, `imageminGenerate`, `imageminNormalizeConfig`, `sharpMinify`,
`sharpGenerate`, `svgoMinify` — so only the plugin they are read off changes.
`squooshMinify` and `squooshGenerate` are not carried over: `@squoosh/lib` is
unmaintained, and `image-minimizer-webpack-plugin` already marked both
deprecated.

A minimizer carries over as it is written: `minimizer` becomes
[`minify`](#minify), with the same `{ implementation, options }` object, and an
array of them stays an array.

**Before**

```js
const ImageMinimizerPlugin = require("image-minimizer-webpack-plugin");

module.exports = {
  plugins: [
    new ImageMinimizerPlugin({
      test: /\.(jpe?g|png)$/i,
      minimizer: {
        implementation: ImageMinimizerPlugin.sharpMinify,
        options: { encodeOptions: { jpeg: { quality: 80 } } },
      },
    }),
  ],
};
```

**After**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  optimization: {
    minimize: true,
    minimizer: [
      new MinimizerPlugin({
        test: /\.(jpe?g|png)$/i,
        minify: {
          implementation: MinimizerPlugin.sharpMinify,
          options: { encodeOptions: { jpeg: { quality: 80 } } },
        },
      }),
    ],
  },
};
```

A generator is where two shapes changed rather than moved. Generators are
**named** here instead of listed, because a name is what `?as=` asks for, so an
array of two generators becomes an object of two entries. And a generator that
produced a file beside the original is written with `type: "asset"`, which is
the default there and not here — without it a generator re-encodes the module
itself, which is what lets the import be renamed.

**Before**

```js
const ImageMinimizerPlugin = require("image-minimizer-webpack-plugin");

module.exports = {
  plugins: [
    new ImageMinimizerPlugin({
      test: /\.(jpe?g|png)$/i,
      generator: [
        {
          type: "asset",
          preset: "webp",
          implementation: ImageMinimizerPlugin.sharpGenerate,
          options: { encodeOptions: { webp: { quality: 90 } } },
        },
      ],
    }),
  ],
};
```

**After**

```js
const MinimizerPlugin = require("minimizer-webpack-plugin");

module.exports = {
  plugins: [
    new MinimizerPlugin({
      test: /\.(jpe?g|png)$/i,
      generate: {
        webp: {
          type: "asset",
          implementation: MinimizerPlugin.sharpGenerate,
          options: { encodeOptions: { webp: { quality: 90 } } },
        },
      },
    }),
  ],
};
```

## Contributing

We welcome all contributions!
If you're new here, please take a moment to review our contributing guidelines before submitting issues or pull requests.

[CONTRIBUTING](https://github.com/webpack/minimizer-webpack-plugin?tab=contributing-ov-file#contributing)

## License

[MIT](./LICENSE)

[npm]: https://img.shields.io/npm/v/minimizer-webpack-plugin.svg
[npm-url]: https://npmjs.com/package/minimizer-webpack-plugin
[node]: https://img.shields.io/node/v/minimizer-webpack-plugin.svg
[node-url]: https://nodejs.org
[tests]: https://github.com/webpack/minimizer-webpack-plugin/workflows/minimizer-webpack-plugin/badge.svg
[tests-url]: https://github.com/webpack/minimizer-webpack-plugin/actions
[cover]: https://codecov.io/gh/webpack/minimizer-webpack-plugin/branch/main/graph/badge.svg
[cover-url]: https://codecov.io/gh/webpack/minimizer-webpack-plugin
[discussion]: https://img.shields.io/github/discussions/webpack/webpack
[discussion-url]: https://github.com/webpack/webpack/discussions
[size]: https://packagephobia.now.sh/badge?p=minimizer-webpack-plugin
[size-url]: https://packagephobia.now.sh/result?p=minimizer-webpack-plugin
